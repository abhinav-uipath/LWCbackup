import { LightningElement,api, track,wire } from 'lwc';
import Knowledgedetails from '@salesforce/apex/EI_NI_knowledgeArticleDetail.Knowledgedetails';
import { CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin } from 'lightning/navigation';

// import OWNER_FIELD from "@salesforce/schema/Knowledge_Article_Categories__c.Owner.Name";

export default class ChildHelpcentreArticleList extends NavigationMixin(LightningElement) {

    @track dynamicButtons = [];
    // @track conList;
    @track error;
    @track knowledgeArticleId = '';
    @track knowledgeRecTitle = 'Joining TDS';
    @track previousPageName = '';

    @api recordId;
    @api firstLink;
    @api secondLink;
    @api thirdLink;
    @api fourthLink;
    @api fifthLink;

    _filterSelection;   
    @api
    set filterSelection(value) {
        // Trigger actions in the child component when the parent property changes
        this._filterSelection = value;
        this.dynamicButtons = [];
        this.connectedCallback();
    }

    get filterSelection() {
        return this._filterSelection;
    }

    // @wire(getRecord, { recordId: "$recordId", fields })
    // knowArtCatObj;
    
    // get ownerName() {
    //     getFieldValue(this.knowArtCatObj, OWNER_FIELD);
    // }

    @wire(CurrentPageReference)
    getPageReferenceParameters(currentPageReference) {
        if (currentPageReference) {
            console.log('Line 29 currentPageReference -> '+JSON.stringify(currentPageReference));
            //   this.recordId = currentPageReference.attributes.recordId || null;
            //   let attributes = currentPageReference.attributes;
            //   let states = currentPageReference.state;
            //   let type = currentPageReference.type;
            
            this.knowledgeArticleId = currentPageReference.attributes.recordId;
            console.log('Line 29 currentPageReference -> '+this.knowledgeArticleId);
        }
    }

    @wire(CurrentPageReference)
    currentPageReference;
   
    connectedCallback() {
         
        console.log('Child component ChildHelpcentreArticleList filterSelection -> '+JSON.stringify(this.filterSelection));
        
        this.loadDynamicButtons();
        
        console.log('Line 65 previousPageName articlelist -> '+this.previousPageName);
        if(this.filterSelection.recordType=='FAQ') {
            this.previousPageName = this.firstLink;
        }
        else if(this.filterSelection.recordType=='Case Study') {
            this.previousPageName = this.secondLink;
        }
        else if(this.filterSelection.recordType=='Guide') {
            this.previousPageName = this.thirdLink;
        }
        else if(this.filterSelection.recordType=='Template') {
            this.previousPageName = this.fourthLink;
        }
        console.log('Line 65 previousPageName articlelist -> '+this.previousPageName);
    }

    @api
    loadDynamicButtons() {
        this.dynamicButtons = [];
        console.log('Child component -> childHelpcentreDocumentList loadDynamicButtons');
        console.log('Line 71 filterSelection -> '+JSON.stringify(this.filterSelection));
        console.log('Line 72 currentPageReference -> '+JSON.stringify(this.currentPageReference));

        if (this.currentPageReference) {
            this.knowledgeArticleId = this.currentPageReference.attributes.recordId;
        }
        
        console.log('Line 78 loadDynamicButtons knowledgeArticleId -> '+this.knowledgeArticleId);      

        Knowledgedetails({ customerType: this.filterSelection.customerType, productType: this.filterSelection.productType, articleType: this.filterSelection.recordType, knowledgeArtId: this.knowledgeArticleId })
            .then(result => {
                // this.conList = result;
                // this.dynamicButtons = result;
                let firstAccordion = true;
                for(let button of result) {
                    let newButton = {Id: button.Id, Title: button.Title, Description__c: button.Description__c, 
                                    accordionClass:"slds-accordion__section"};
                    if(firstAccordion) {
                        newButton.accordionClass = 'slds-accordion__section slds-is-open';
                        firstAccordion = false;
                    }
                    this.dynamicButtons.push(newButton);
                }           
                console.log('Line 76 succes -> '+JSON.stringify(this.dynamicButtons));
                if(result.length>0) {
                    this.knowledgeRecTitle = result[0].Knowledge_Article_Category__r.Name;
                }

                // this.dynamicButtons = result;                
                // console.table(this.dynamicButtons);
                // this.loadKnowledgeDetails();
            })
            .catch(error => {
                console.error('Error retrieving dynamic buttons:', error);
            });
            
    }

    handleAccordionChange(event) {
        event.preventDefault();

        console.log('Line 118 accordion li key -> '+event.currentTarget.dataset.id);
        let currentKnowledgId = event.currentTarget.dataset.id;
        for(let button of this.dynamicButtons) {
            if(button.Id == currentKnowledgId) {
                console.log('Line 123 -> '+currentKnowledgId);
                if(button.accordionClass=='slds-accordion__section') {
                    button.accordionClass = 'slds-accordion__section slds-is-open';
                }
                else {
                    button.accordionClass = 'slds-accordion__section';
                }
            }
            else {
                button.accordionClass = 'slds-accordion__section';
            }
        }
        console.log('Line 130 accordion li key -> ');
        
    }

    backToHelpCenter(event) {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: this.previousPageName
            }
        });
    }

}