import { LightningElement,api, track,wire } from 'lwc';
import KnowledgedetailsWithFiles from '@salesforce/apex/EI_NI_knowledgeArticleDetail.KnowledgedetailsWithFiles';
import { CurrentPageReference } from 'lightning/navigation';
import NI_TDS_Website_assets from '@salesforce/resourceUrl/NI_TDS_Website_assets';


export default class ChildHelpcentreDocumentList extends LightningElement {
    
    docIcon = NI_TDS_Website_assets+'/assets/img/docicon.svg';

    _filterSelection;   
    @api
    set filterSelection(value) {
        // Trigger actions in the child component when the parent property changes
        this._filterSelection = value;
        this.dynamicButtons=[];
        this.connectedCallback();
    }

    get filterSelection() {
        return this._filterSelection;
    }

    // @api filterSelection = {customerType: 'Tenant', productType: 'Custodial',recordType:'Case Study'};

    @track dynamicButtons=[];
    @track conList;
    @track error;
    @track knowledgeArticleId = '';
    @track backButtonLabel = '';
    @track knowledgeRecTitle = 'Trending Articles';
    @track previousPageName='';

    @api recordId;
    @api firstLink;
    @api secondLink;
    @api thirdLink;
    @api fourthLink;
    @api fifthLink;
   
    @wire(CurrentPageReference)
    getPageReferenceParameters(currentPageReference) {
        if (currentPageReference) {
            console.log('Line 29 currentPageReference -> '+JSON.stringify(currentPageReference));
            this.knowledgeArticleId = currentPageReference.attributes.recordId;
            console.log('Line 29 currentPageReference -> '+this.knowledgeArticleId);
        }
    }

    @wire(CurrentPageReference)
    currentPageReference;

    connectedCallback() {         
        console.log('Child component ChildHelpcentreDocumentList connectedCallback called with parentProperty:'+JSON.stringify(this.filterSelection));

        console.log('Line 55 child component childHelpcentreDocumentList -> '+JSON.stringify(this.filterSelection));
        
        this.loadDynamicButtons();
        
        console.log('Line 65 previousPageName documentlist -> '+this.previousPageName);
        if(this.filterSelection.recordType=='FAQ') {
            this.previousPageName = this.firstLink;
        }
        else if(this.filterSelection.recordType=='Case Study') {
            this.previousPageName = this.secondLink;
        }
        else if(this.filterSelection.recordType=='Guide') {
            this.previousPageName = this.thirdLink;
        }
        else if(this.filterSelection.recordType=='Template') {
            this.previousPageName = this.fourthLink;
        }
        console.log('Line 65 previousPageName documentlist -> '+this.previousPageName);
    }

    @api
    loadDynamicButtons() {
        this.dynamicButtons = [];
        // this.filterSelection = filterSelection;
        console.log('Child component -> childHelpcentreDocumentList loadDynamicButtons');
        console.log('Line 77 filterSelection -> '+JSON.stringify(this.filterSelection));
        console.log('Line 78 currentPageReference -> '+JSON.stringify(this.currentPageReference));

        if (this.currentPageReference) {
            this.knowledgeArticleId = this.currentPageReference.attributes.recordId;
        }
        
        console.log('Line 84 loadDynamicButtons knowledgeArticleId -> '+this.knowledgeArticleId);

        if(this.filterSelection.recordType=='Casestudy') {
            console.log('Line 100 -> '+this.filterSelection.recordType);
            // this.filterSelection.recordType = 'Case study';
            this.filterSelection = {customerType: this.filterSelection.customerType, productType: this.filterSelection.productType, recordType: 'Case Study'};
            console.log('Line 100 recordType -> '+this.filterSelection.recordType);
        }
        
        KnowledgedetailsWithFiles({ customerType: this.filterSelection.customerType, productType: this.filterSelection.productType, articleType: this.filterSelection.recordType, knowledgeArtId: this.knowledgeArticleId })
            .then(result => {
                console.log('Line 99 KnowledgedetailsWithFiles -> '+JSON.stringify(result));
                if(result.length>0) {
                    // let mapOfKnowledgeWithPubliUrl = Object.entries(result[0].mapOfKnowledgeWithPubliUrl).map(([key,value])=>({ key, value }));
                    let mapOfKnowledgeWithPubliUrl = result[0].mapOfKnowledgeWithPubliUrl;
                    console.log('Line 104 mapOfKnowledgeWithPubliUrl -> '+JSON.stringify(mapOfKnowledgeWithPubliUrl));

                    if(result[0].knowledgeArticleList.length>0) {
                        console.log('Line 140 knowledgeRecTitle -> '+result[0].knowledgeArticleList[0].Knowledge_Article_Category__r.Name);
                        this.knowledgeRecTitle = result[0].knowledgeArticleList[0].Knowledge_Article_Category__r.Name;
                    }

                    for(let button of result[0].knowledgeArticleList) {
                        let newButton = {Id: button.Id, Title: button.Title, downloadUrl: ''};
                        console.log('Line 114 newButton -> '+newButton);
                        console.log('Line 114 button.id -> '+button.Id);

                        // if(mapOfKnowledgeWithPubliUrl.has(button.id)) {
                        //     newButton.downloadUrl = mapOfKnowledgeWithPubliUrl.get(button.id);
                        //     console.log('Line 121 downloadUrl -> '+newButton.downloadUrl);
                        // }
                        // else {
                        //     newButton.downloadUrl = '';
                        // }

                        for(let key of Object.keys(mapOfKnowledgeWithPubliUrl)) {
                            console.log('Line 134 key -> '+key);
                            if(key==button.Id) {
                                console.log('Line 135 -> download found -> '+mapOfKnowledgeWithPubliUrl[key]);
                                newButton.downloadUrl = mapOfKnowledgeWithPubliUrl[key];
                            }
                        }
                        this.dynamicButtons.push(newButton);
                    }
                    console.log('Line 142 -> '+JSON.stringify(this.dynamicButtons));
                }
            })
            .catch(error => {
                console.error('Error retrieving dynamic buttons:', error);
            });

    }

}