import { LightningElement, track, wire } from 'lwc';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import SFChatter from '@salesforce/resourceUrl/SFChatter';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import getClaimDetailsByAccessCode from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.getClaimDetailsByAccessCode';
// import {CurrentPageReference } from 'lightning/navigation';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import UpdateCaseInRepaymentAgreementbyAgll from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.UpdateCaseInRepaymentAgreementbyAgll';
import updateCaseInOfferMadebyAGll from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateCaseInOfferMadebyAGll';
import updateCaseInSelfOfferCancelledbyAGll from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateCaseInSelfOfferCancelledbyAGll';
import updateCaseWhenAGllAcceptTenantOffer from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateCaseWhenAGllAcceptTenantOffer';
import updateCaseWhenAGllRejectTenantOffer from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateCaseWhenAGllRejectTenantOffer';
import updateRepaymentAdjustmentbyAGLL from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateRepaymentAdjustmentbyAGLL';
import UpdateCaseNoAgreementBYAGll from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.UpdateCaseNoAgreementBYAGll';
import updateChatFields from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateChatFields';
import updateChatHistory from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.updateChatHistory';
import getSecureURI from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.getSecureURI';
import saveFile from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.saveFile';
import returnUnreadMessages from '@salesforce/apex/EWI_EI_SelfResolutionJourneyClass.returnUnreadMessages';
import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

import SystemModstamp from '@salesforce/schema/Account.SystemModstamp';

export default class Ewi_EI_SelfResolutionForAGLLViewOnly extends NavigationMixin(LightningElement) {

    
    
    dropLeftArrowIcon = EWITheme + '/assets/img/ew-arrow-dropleft.png';
thankyoucircleIcon = EWITheme + '/assets/img/circle_checked_icon.png'; 
usericon = EWITheme  + '/assets/img/User_Icon.png';
minimizeicon = EWITheme  + '/assets/img/minimize-icon.png';
closeicon = EWITheme  + '/assets/img/close-icon.png';
addicon = EWITheme  + '/assets/img/add-icon.png';

renderedCallback() {

  Promise.all([
      loadStyle(this, SFChatter  + '/assets/css/custom.css')
      
      
  ])
      .then(() => {
         // alert('Files loaded.');
      })
      .catch(error => {
          alert(error.body.message);
      });
  }


@track claimdetails;
@track accessCode;
@track Unsolvedamount;
@track responddate;
@track checkother =false;
@track dispitemlist=[];
@track agllAgreed = false;
@track amountToAGLLIfAgllAgreement;
@track amountToTenantIfAgllAgreement;
@track thankyousection =false;
@track thankYouSectionForAgree=false;
@track thankYouSectionForMakeOffer=false;
@track thankYouSectionForAGllAcceptAnOffer = false;
@track thankYouSectionForAGllRejectAnOffer = false;
@track casedata;
@track agllmakeoffer=false;
@track agllMakeOfferSideGreyTab=false;
@track agllAgreedSideGreyTab=true;
@track offeramountbyAGlltoAGll='';
@track amountotenantinoffercase;
@track offerMadeByAGll=false;
@track offermadebyAGllamounttoAGLL;
@track offermadebyAGllamounttoTenant;
@track showbuttonsection=true;
@track offerErrorMessage;
@track isError = false;
@track viewAndRespondOnTenantOffer=false;
@track tenantofferamounttoAgll;
@track amounttotenantoffermadebytenant;
@track showforcounteroffer=false;
@track mainfacingpage=true;
@track doadjustment = false;
@track disputeOldRecMap;
@track totalTenantAmount;
@track totalAGLLAmount;
@track adjustmentByAGll = false;
@track adjustmentamountAGLL ;
@track adjustmentamounttoTT ;
@track thankYouSectionForAGllDisagreeForTenant=false;
@track thankYouSectionForNoAggrementByAGll=false;
@track totalAdjustedAmountbyAGll = 0.00;
@track isNotAgreedBtnClicked=false;
@track notreachagreementcomment;
@track isErrornew =false;
@track errorMsgnew;
@track disableslider=false;
@track makebuttondisable = false;
@track chatWrap = {};
  @track chatList = [];
  @track chatOpen = false;
  @track messageValue;
  @track showEvidenceCmp=false;
  @track fileName;
  @track message;
  @track fileLable;
  @track fileLableVisible =false;
  @track fileList;
  @track secureURI;
  @track azureLink;
  @track isadjustsubmit = true;
  @track shownotification = false;
  @track showunreadcount;
  @track isShowDeadlineMSG = false;
  @track showDetails=true;

  changechattertext(event){
    this.messageValue = event.target.value;
  }

    handleErrorMsg(){
      this.isErrornew = false;
    }

    addtwodecimalplaces(dummyamount){
      var checkdecimalplace = dummyamount.split(".");
      if(checkdecimalplace.length<2){
       return dummyamount+'.00';
      }
      else{
      if(checkdecimalplace[1].length<2)
      return dummyamount+'0';
      else{
       return dummyamount;
      }
      }
      
     
      }

changeofferamount(event){
  this.isError = false;
  if(!event.target.value 
    //  || !event.target.value.match(/^[0-9]+$/)
     ){
    this.offeramountbyAGlltoAGll = null;
    this.amountotenantinoffercase = '£'+Number(this.casedata.Total_Deposit__c.toFixed(2)).toLocaleString("en-US");
  }
  else{

  if(!(event.target.value).includes('£')){
  this.offeramountbyAGlltoAGll ='£'+Number((parseFloat(event.target.value)).toFixed(2)).toLocaleString("en-US");
  this.amountotenantinoffercase = '£'+Number((this.casedata.Total_Deposit__c-(parseFloat(event.target.value))).toFixed(2)).toLocaleString("en-US");
  }
  else{
      let str = event.target.value;
      str = str.substring(1);
      this.offeramountbyAGlltoAGll = '£'+Number((parseFloat(str)).toFixed(2)).toLocaleString("en-US");
      this.amountotenantinoffercase = '£'+Number((this.casedata.Total_Deposit__c-parseFloat(str)).toFixed(2)).toLocaleString("en-US");
  }
}
 }


@wire(CurrentPageReference)
getpageRef(pageRef){
  setTimeout(() => { window.history.forward();  }, 0);

    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const recId = urlParams.get('accessCode');
    this.accessCode = recId;
    if(recId == '' || recId == null){
      this.showDetails = false;
      return;
  }  

        
    getClaimDetailsByAccessCode({AccessCode : recId}).then(result =>{
      if(result==null){
        this.showDetails = false;
        return;
      }
      this.showDetails = true;
        this.claimdetails = result;
        this.casedata = result[0];

        if(result[0].Status == 'Self-resolution'){
          this.isShowDeadlineMSG = true;
        }

        this.Unsolvedamount = result[0].Total_Claimed_by_Landlord__c - result[0].Claimed_by_Tenant__c;
        var claimdate =new Date(result[0].Respond_Date__c);
        this.amountotenantinoffercase ='£'+Number((result[0].Total_Deposit__c-this.offeramountbyAGlltoAGll).toFixed(2)).toLocaleString("en-US") ;
        this.notreachagreementcomment = result[0].Not_reach_an_agreement_Reason_AG_LL__c;

        if(!claimdate){
            this.responddate='';   
           }
     if (claimdate){
        var checkdate = claimdate.getDate().toString().padStart(2, "0");;
        var checkmonth = (claimdate.getMonth()+1).toString().padStart(2, "0");
        var checkyear = claimdate.getFullYear();
        var newDate = checkdate +'/'+ checkmonth+'/'+checkyear;
        this.responddate = newDate;
     }

     
       // Amount spilt b/w AGLL and TT When Tenant Agreed AGll Repayment Start//
        this.amountToAGLLIfAgllAgreement = '£'+Number(result[0].Total_Agreed_by_Tenant__c.toFixed(2)).toLocaleString("en-US");
        this.amountToTenantIfAgllAgreement = '£'+Number((result[0].Total_Claimed_by_Landlord__c-result[0].Total_Agreed_by_Tenant__c).toFixed(2)).toLocaleString("en-US");
       // Amount spilt b/w AGLL and TT When Tenant Agreed AGll Repayment End// 


       if(result[0].AGLL_made_Offer__c==true && result[0].AGLL_Offer_Amount__c >0 ){
        // this.offermadebyAGllamounttoAGLL = '£'+Number(result[0].AGLL_Offer_Amount__c.toFixed(2)).toLocaleString("en-US");
        // this.offermadebyAGllamounttoTenant = '£'+Number((result[0].Total_Deposit__c-result[0].AGLL_Offer_Amount__c).toFixed(2)).toLocaleString("en-US");
        
        this.offermadebyAGllamounttoAGLL = '£'+(result[0].AGLL_Offer_Amount__c).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
        this.offermadebyAGllamounttoAGLL = this.addtwodecimalplaces(this.offermadebyAGllamounttoAGLL);

        this.offermadebyAGllamounttoTenant = '£'+(result[0].Total_Deposit__c-result[0].AGLL_Offer_Amount__c).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
        this.offermadebyAGllamounttoTenant = this.addtwodecimalplaces(this.offermadebyAGllamounttoTenant);
       
        this.offerMadeByAGll=true;
        this.showbuttonsection=false;

        }

        if(result[0].TT_Made_offer__c==true && result[0].TT_Offer_Amount__c >0 ){
          this.viewAndRespondOnTenantOffer=true;
          this.showbuttonsection=true;
          this.makebuttondisable = true;  
          this.showforcounteroffer = true;
          // this.template.querySelector('.agreementbutton').classList.add('disablebutton');
          // this.template.querySelector('.disagreebutton').classList.add('disablebutton');
          // this.template.querySelector('.offerbutton').classList.add('disablebutton');
          
          // this.tenantofferamounttoAgll = '£'+Number(result[0].TT_Offer_Amount__c.toFixed(2)).toLocaleString("en-US");
          // this.amounttotenantoffermadebytenant = '£'+Number((result[0].Total_Deposit__c-result[0].TT_Offer_Amount__c).toFixed(2)).toLocaleString("en-US");
          
          this.tenantofferamounttoAgll = '£'+(result[0].TT_Offer_Amount__c).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
          this.tenantofferamounttoAgll = this.addtwodecimalplaces(this.tenantofferamounttoAgll);

          this.amounttotenantoffermadebytenant = '£'+(result[0].Total_Deposit__c-result[0].TT_Offer_Amount__c).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
          this.amounttotenantoffermadebytenant = this.addtwodecimalplaces(this.amounttotenantoffermadebytenant);
        
        }
        else{
          // this.template.querySelector('.agreementbutton').classList.remove('disablebutton');
          // this.template.querySelector('.disagreebutton').classList.remove('disablebutton');
          // this.template.querySelector('.offerbutton').classList.remove('disablebutton');

        }


    //  let dispitemlist=[];
    //  result[0].Dispute_Items__r.forEach(claimdata =>{
    //     if(claimdata.Type__c == 'Other'){
    //         dispitemlist.push({ label: claimdata.Type__c,  value: true, amountagreedbyagll: claimdata.Agreed_by_AGLL__c.toFixed(2) , placeholderagent: '£'+claimdata.Agreed_by_AGLL__c.toFixed(2),  
    //         amountagreedbytt:claimdata.Agreed_by_Tenant__c, placeholdertenant: '£'+claimdata.Agreed_by_Tenant__c.toFixed(2),recordid:claimdata.Id ,adjperbyAGLL: claimdata.Adjustment_Percentage_by_AGLL__c,AdjprcntbyTT: claimdata.Adjustment_Percentage_by_TT__c,initialClaimOfagll: claimdata.Claimed_by_Landlord__c , otherreasonagll: claimdata.Other_Reason__c });
    //       }
    //       else {
    //         dispitemlist.push({ label: claimdata.Type__c,  value: false, amountagreedbyagll: claimdata.Agreed_by_AGLL__c.toFixed(2), placeholderagent: '£'+claimdata.Agreed_by_AGLL__c.toFixed(2) , 
    //         amountagreedbytt:claimdata.Agreed_by_Tenant__c, placeholdertenant: '£'+claimdata.Agreed_by_Tenant__c.toFixed(2),recordid:claimdata.Id , adjperbyAGLL: claimdata.Adjustment_Percentage_by_AGLL__c,AdjprcntbyTT: claimdata.Adjustment_Percentage_by_TT__c,initialClaimOfagll: claimdata.Claimed_by_Landlord__c , otherreasonagll: claimdata.Other_Reason__c });
    //     }
    // });

    let dispitemlist=[];
    dispitemlist.push({label:'Cleaning'});
    dispitemlist.push({label:'Damage'});
    dispitemlist.push({label:'Redecoration'});
    dispitemlist.push({label:'Gardening'});
    dispitemlist.push({label:'Rent'});
    dispitemlist.push({label:'Other'});

      for(let i=0; i<dispitemlist.length; i++){
        let flag=false;
        result[0].Dispute_Items__r.forEach(claimdata =>{
          if(dispitemlist[i].label == claimdata.Type__c ){
            flag = true;
            // if(claimdata.Type__c == 'Other'){
              dispitemlist[i]['value']= claimdata.Type__c == 'Other'?true:false;
              dispitemlist[i]['amountagreedbyagll']= claimdata.Agreed_by_AGLL__c; // .toFixed(2);
              // dispitemlist[i]['placeholderagent']= '£'+claimdata.Agreed_by_AGLL__c.toFixed(2);
              //dispitemlist[i]['placeholderagent']= '£'+Number(claimdata.Agreed_by_AGLL__c.toFixed(2)).toLocaleString("en-US")+(claimdata.Type__c == 'Other'?'\n'+claimdata.Other_Reason__c:'');
              dispitemlist[i]['placeholderagent']= '£'+claimdata.Agreed_by_AGLL__c.toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2});
              dispitemlist[i]['placeholderagent'] = this.addtwodecimalplaces(dispitemlist[i]['placeholderagent'])+(claimdata.Type__c == 'Other'?'\n'+claimdata.Other_Reason__c:'');
              dispitemlist[i]['amountagreedbytt']= claimdata.Agreed_by_Tenant__c;
             // dispitemlist[i]['placeholdertenant']= '£'+Number(claimdata.Agreed_by_Tenant__c.toFixed(2)).toLocaleString("en-US");
              dispitemlist[i]['placeholdertenant']= '£'+claimdata.Agreed_by_Tenant__c.toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2});
              dispitemlist[i]['placeholdertenant'] = this.addtwodecimalplaces(dispitemlist[i]['placeholdertenant']);
              dispitemlist[i]['recordid']=claimdata.Id;
              dispitemlist[i]['adjperbyAGLL']= claimdata.Adjustment_Percentage_by_AGLL__c;
              dispitemlist[i]['AdjprcntbyTT']= claimdata.Adjustment_Percentage_by_TT__c;
              dispitemlist[i]['initialClaimOfagll']= claimdata.Claimed_by_Landlord__c;
              dispitemlist[i]['otherreasonagll']= claimdata.Other_Reason__c;              
            // }
            // else {
            //   dispitemlist[i]['value']= false;
            //   dispitemlist[i]['amountagreedbyagll']= claimdata.Agreed_by_AGLL__c.toFixed(2);
            //   dispitemlist[i]['placeholderagent']= '£'+claimdata.Agreed_by_AGLL__c.toFixed(2);
            //   dispitemlist[i]['amountagreedbytt']= claimdata.Agreed_by_Tenant__c;
            //   dispitemlist[i]['placeholdertenant']= '£'+claimdata.Agreed_by_Tenant__c.toFixed(2);
            //   dispitemlist[i]['recordid']=claimdata.Id;
            //   dispitemlist[i]['adjperbyAGLL']= claimdata.Adjustment_Percentage_by_AGLL__c;
            //   dispitemlist[i]['AdjprcntbyTT']= claimdata.Adjustment_Percentage_by_TT__c;
            //   dispitemlist[i]['initialClaimOfagll']= claimdata.Claimed_by_Landlord__c;
            //   dispitemlist[i]['otherreasonagll']= claimdata.Other_Reason__c;              
            // }
          }
        });
        if(flag == false){
          dispitemlist.splice(i ,1);
          i--;
        }
      }

    this.dispitemlist=dispitemlist;
    console.log('line no. 318 ->' + this.dispitemlist);


    let disputOldRecMap = new Map();
    let caseItemRec = result[0].Dispute_Items__r;
    let totalamount = 0;
    let totalamountAGLL = 0;
    for(let i=0; i<caseItemRec.length;i++)
    {
        var AmountObj = new Object();
        AmountObj.Amount = caseItemRec[i].Agreed_by_AGLL__c;
        AmountObj.Percentage = caseItemRec[i].Adjustment_Percentage_by_AGLL__c;
        disputOldRecMap.set(caseItemRec[i].Id,AmountObj);

    if(caseItemRec[i].Agreed_by_Tenant__c)
        {
            totalamount = parseFloat(totalamount)+ parseFloat(caseItemRec[i].Agreed_by_Tenant__c);
        }
        if(caseItemRec[i].Agreed_by_AGLL__c)
        {
            totalamountAGLL = parseFloat(totalamountAGLL)+ parseFloat(caseItemRec[i].Agreed_by_AGLL__c);
        }            
    }
    this.totalTenantAmount = totalamount;
    this.totalAGLLAmount =totalamountAGLL;
    this.disputeOldRecMap = disputOldRecMap;
    console.log('line-->154 ' +  this.disputeOldRecMap);
    
    this.totalAdjustedAmountbyAGLL = parseFloat(totalamountAGLL);
    // this.adjustmentamountAGLL = '£'+Number(totalamountAGLL.toFixed(2)).toLocaleString("en-US");
    // this.adjustmentamounttoTT = '£'+Number((this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamountAGLL)).toFixed(2)).toLocaleString("en-US");
    
    this.adjustmentamountAGLL = '£'+(totalamountAGLL).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
    this.adjustmentamountAGLL = this.addtwodecimalplaces(this.adjustmentamountAGLL);

    this.adjustmentamounttoTT = '£'+(this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamountAGLL)).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
    this.adjustmentamounttoTT = this.addtwodecimalplaces(this.adjustmentamounttoTT);

    }).catch(error => {

    });

    returnUnreadMessages({accessCode : recId })
    .then(result => {
      this.showunreadcount = result;
      // alert('line 328 ' + this.showunreadcount);
      if(this.showunreadcount > 0){
        this.shownotification = true;
      }
      else{
        this.shownotification = false;  
      }
      
      
    })
    .catch(error => {
      console.log('returnUnreadMessages error--->'+JSON.stringify(error));
    });


}


agllAgreementoftenantrepayment(){
  // this.template.querySelector('.agreementbutton').classList.add('buttoncolor');
  // this.template.querySelector('.disagreebutton').classList.remove('buttoncolor');
  // this.template.querySelector('.offerbutton').classList.remove('buttoncolor');

    this.disableslider=true;
    this.agllAgreed=true;
    this.doadjustment = false;
    this.mainfacingpage = true;
    this.agllmakeoffer=false;
    this.adjustmentByAGll=false;
    this.agllMakeOfferSideGreyTab=false;
    this.agllAgreedSideGreyTab=true;
    this.isNotAgreedBtnClicked=false;
    
}

agllAgreedAgllRequestsubmit(){
  //alert('line-->88' + typeof this.casedata);
  console.log('line-->89' + JSON.stringify(this.casedata) );

  UpdateCaseInRepaymentAgreementbyAgll({caseId: this.casedata.Id, agreedAmount: this.casedata.Total_Agreed_by_Tenant__c, depositAmount : this.casedata.Total_Deposit__c})
 .then(result => {
 
   // on success, you can bind to a tracked vars to re-render them
   console.log('UpdateCaseInRepaymentAgreementbyAgll result--->'+JSON.stringify(result));
   this.thankyousection =true;
   this.thankYouSectionForAgree=true;
   this.thankYouSectionForMakeOffer=false;
   this.thankYouSectionForAGllRejectAnOffer =false;
   this.thankYouSectionForAGllAcceptAnOffer =false;

 })
 .catch(error => {
   console.log('UpdateCaseInRepaymentAgreementbyAgll error--->'+JSON.stringify(error));
 });
}

agllMakeOfferToTenant(){
  // this.template.querySelector('.agreementbutton').classList.remove('buttoncolor');
  // this.template.querySelector('.disagreebutton').classList.remove('buttoncolor');
  // this.template.querySelector('.offerbutton').classList.add('buttoncolor');

  this.showbuttonsection=false;
  this.mainfacingpage = false;
  this.doadjustment = true;  
  this.disableslider=true;
  this.agllmakeoffer=true;
  this.agllAgreed=false;
  this.adjustmentByAGll=false;
  this.agllMakeOfferSideGreyTab=true;
  this.agllAgreedSideGreyTab=false;
  this.isNotAgreedBtnClicked=false;
  
  
}

submitOfferByAgll(){
  let str = this.offeramountbyAGlltoAGll;
  str = str.substring(1);
  str = str.replaceAll(',','');
  var finalofferamount = (parseFloat(str));
  var isValid=true;
  

  if (!finalofferamount ||finalofferamount < 0 || finalofferamount =='' || finalofferamount == undefined || finalofferamount == null){
    isValid = false;
    this.isError = true;
    this.offerErrorMessage = "Enter valid offer amount";

  }

  if (finalofferamount > this.casedata.Total_Agreed_by_AG_LL__c ){
    isValid = false;
    this.isError = true;
    this.offerErrorMessage = "You have entered more than the requested amount. Please review your offer.";

  }
  

  if (finalofferamount > 0 && finalofferamount !='' && finalofferamount != undefined && finalofferamount != null){
  if (finalofferamount < this.casedata.Total_Agreed_by_Tenant__c ){
    isValid = false;
    this.isError = true;
    this.offerErrorMessage = "You have entered less than the agreed amount by tenant. Please review your offer.";

  }
}
  
  
  if(isValid){
  updateCaseInOfferMadebyAGll({caseId: this.casedata.Id, offeramount: finalofferamount, depositAmount : this.casedata.Total_Deposit__c})
  .then(result => {
  
    // on success, you can bind to a tracked vars to re-render them
    console.log('updateCaseInOfferMadebyAGll result--->'+JSON.stringify(result));
    this.thankyousection =true;
    this.thankYouSectionForAgree=false;
    this.thankYouSectionForMakeOffer=true;
    this.thankYouSectionForAGllRejectAnOffer =false;
    this.thankYouSectionForAGllAcceptAnOffer =false;

  })
  .catch(error => {
    console.log('updateCaseInOfferMadebyAGll error--->'+JSON.stringify(error));
  });
}
}

doNotMakeOfferByAGll(){
  // this.template.querySelector('.agreementbutton').classList.remove('buttoncolor');
  // this.template.querySelector('.disagreebutton').classList.remove('buttoncolor');
  // this.template.querySelector('.offerbutton').classList.remove('buttoncolor');

  this.agllmakeoffer=false;
  this.isNotAgreedBtnClicked=false;
  if(this.showforcounteroffer==true ){
    this.viewAndRespondOnTenantOffer=true; 
    this.showbuttonsection=true;
  }
  if(this.showforcounteroffer==false ){
    this.viewAndRespondOnTenantOffer=false;
    this.showbuttonsection=true;
  }
}

selfOfferCancelByAGll(){
  updateCaseInSelfOfferCancelledbyAGll({caseId: this.casedata.Id})
  .then(result => {
  
    // on success, you can bind to a tracked vars to re-render them
    console.log('updateCaseInRepaymentAgreementbyTenant result--->'+JSON.stringify(result));
    this.offerMadeByAGll=false;
    this.showbuttonsection=true;

  })
  .catch(error => {
    console.log('updateCaseInRepaymentAgreementbyTenant error--->'+JSON.stringify(error));
  });

}

tenantOfferAcceptedByAGll(){

updateCaseWhenAGllAcceptTenantOffer({caseId: this.casedata.Id,amounttoagll:this.casedata.TT_Offer_Amount__c,depositamount:this.casedata.Total_Deposit__c})
.then(result => {
  // on success, you can bind to a tracked vars to re-render them
  console.log('updateCaseWhenAGllAcceptTenantOffer result--->'+JSON.stringify(result));
  this.thankyousection =true;
  this.thankYouSectionForAGllAcceptAnOffer =true;
  this.thankYouSectionForMakeOffer=false;
  this.thankYouSectionForAGllRejectAnOffer =false;
  this.thankYouSectionForAgree=false;

})
.catch(error => {
  console.log('updateCaseWhenAGllAcceptTenantOffer error--->'+JSON.stringify(error));
});

}

tanantOfferRejectedByAGll(){
updateCaseWhenAGllRejectTenantOffer({caseId: this.casedata.Id})
.then(result => {
  // on success, you can bind to a tracked vars to re-render them
  console.log('updateCaseWhenAGllRejectTenantOffer result--->'+JSON.stringify(result));
  this.thankyousection =true;
  this.thankYouSectionForAGllRejectAnOffer =true;
  this.thankYouSectionForAGllAcceptAnOffer =false;
  this.thankYouSectionForMakeOffer=false;
  this.thankYouSectionForAgree=false;

})
.catch(error => {
  console.log('updateCaseWhenAGllRejectTenantOffer error--->'+JSON.stringify(error));
});

}

counterOfferByAGll(){
  this.disableslider=true;
  this.agllmakeoffer=true;
  this.mainfacingpage = false;
  this.doadjustment = true;  
  this.agllAgreed=false;
  this.agllMakeOfferSideGreyTab=true;
  this.agllAgreedSideGreyTab=false;
  this.viewAndRespondOnTenantOffer=false;
  this.isNotAgreedBtnClicked=false;
}

doadjustmentbyAGLL(){
// this.template.querySelector('.agreementbutton').classList.remove('buttoncolor');
// this.template.querySelector('.disagreebutton').classList.add('buttoncolor');
// this.template.querySelector('.offerbutton').classList.remove('buttoncolor');

console.log('line 328--->');   
this.disableslider=false;
this.mainfacingpage = false;
this.doadjustment = true;
this.adjustmentByAGll=true;
this.agllmakeoffer=false;
this.agllAgreed=false;
this.agllMakeOfferSideGreyTab=true;
this.isNotAgreedBtnClicked=false;
this.agllAgreedSideGreyTab=false;
this.isadjustsubmit = true;
setTimeout(() => {
  this.template.querySelector('.disablesubmit').classList.add('disablebutton');
  }, 500);
}

handleInput (event) {
let totalamount = 0;
// Html input  Tag
let selectRecordValue = event.target.value;
let selectRecordId = event.target.title;
console.log('recordid 332 ' + selectRecordId);
console.log('selectRecordValue 333 ' + selectRecordValue);
// Lightning input Tag
// let selectRecordValue = event.getSource().get("v.value");
// let selectRecordId = event.getSource().get("v.id");

let disputOldRecMap = this.disputeOldRecMap;
console.log('disputOldRecMap 339  ' + JSON.stringify(this.disputeOldRecMap));
let claimRec = this.dispitemlist; // this.casedata.Dispute_Items__r;
console.log('claimRec ' + JSON.stringify(claimRec));
for(let i =0; i< claimRec.length; i++)
{ 
console.log('claimRec[i].recordId ' + claimRec[i].recordid);
console.log('disputOldRecMap.get(selectRecordId).Amount ' + disputOldRecMap.get(selectRecordId).Amount);

  if(claimRec[i].recordid == selectRecordId)
    {
      console.log('record ID matched ' + selectRecordValue);
      if(selectRecordValue < 0 )
      {
        claimRec[i].showerror = true;
        claimRec[i].errormsg = 'You cannot enter a negative figure';
        claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
        this.isadjustsubmit = true;
        this.template.querySelector('.disablesubmit').classList.add('disablebutton');
      }
      if(selectRecordValue > 0){
        if(selectRecordValue  > disputOldRecMap.get(selectRecordId).Amount )
        {
            claimRec[i].showerror = true;
            // claimRec[i].errormsg = 'You can only reduce the amount';
            claimRec[i].errormsg = 'You are unable to increase the amount requested, please enter a reduced value.';
            claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
            this.isadjustsubmit = true;
            this.template.querySelector('.disablesubmit').classList.add('disablebutton');
        }
        else
        {
            if(selectRecordValue < claimRec[i].amountagreedbytt )
            {
                claimRec[i].showerror = true;
                claimRec[i].errormsg = 'Amount entered should be equal to or greater than amount requested by tenant';
                claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
                this.isadjustsubmit = true;
                this.template.querySelector('.disablesubmit').classList.add('disablebutton');
            }
            else
                {
                  this.isadjustsubmit = false;
                  this.template.querySelector('.disablesubmit').classList.remove('disablebutton');
                  claimRec[i].showerror = false;
                  claimRec[i].amountagreedbyagll = selectRecordValue; // parseFloat(selectRecordValue).toFixed(2);
                }
            
        }
        //claimRec[i].Agreed_by_Tenant__c = selectRecordValue;
        var AGLLResponseperc = (claimRec[i].amountagreedbyagll * 100 )/claimRec[i].initialClaimOfagll;
        claimRec[i].adjperbyAGLL = AGLLResponseperc;
      }
    }
  
    totalamount = parseFloat(totalamount) + parseFloat(claimRec[i].amountagreedbyagll);
    this.totalAdjustedAmountbyAGLL = parseFloat(totalamount);
    // this.adjustmentamountAGLL = '£'+Number(totalamount.toFixed(2)).toLocaleString("en-US");
    // this.adjustmentamounttoTT = '£'+Number((this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamount)).toFixed(2)).toLocaleString("en-US");
    
    this.adjustmentamountAGLL = '£'+(totalamount).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
    this.adjustmentamountAGLL = this.addtwodecimalplaces(this.adjustmentamountAGLL);

    this.adjustmentamounttoTT = '£'+(this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamount)).toLocaleString({minimumFractionDigits: 2}, {maximumFractionDigits: 2}); 
    this.adjustmentamounttoTT = this.addtwodecimalplaces(this.adjustmentamounttoTT);

    console.log('line-->402 ' + totalamount);
}

this.dispitemlist = claimRec;

}

sliderMethod(event){
let totalamount = 0;
// Html input  Tag
let selectRecordValue = event.target.value;
let selectRecordId = event.target.title;
console.log('recordid 332 ' + selectRecordId);
console.log('selectRecordValue 333 ' + selectRecordValue);
// Lightning input Tag
// let selectRecordValue = event.getSource().get("v.value");
// let selectRecordId = event.getSource().get("v.id");

let disputOldRecMap = this.disputeOldRecMap;
console.log('disputOldRecMap 339  ' + JSON.stringify(this.disputeOldRecMap));
let claimRec = this.dispitemlist; // this.casedata.Dispute_Items__r;
console.log('claimRec ' + JSON.stringify(claimRec));
for(let i =0; i< claimRec.length; i++)
{ 
claimRec[i].showerror = false;
console.log('claimRec[i].recordId ' + claimRec[i].recordid);
console.log('disputOldRecMap.get(selectRecordId).Amount ' + disputOldRecMap.get(selectRecordId).Amount);

if(claimRec[i].recordid == selectRecordId)
  {
    console.log('record ID matched ' + selectRecordValue);
    // if(selectRecordValue < 0 )
    // {
    //   claimRec[i].showerror = true;
    //   claimRec[i].errormsg = 'You cannot enter a negative figure';
    //   claimRec[i].amountagreedbyagll = disputOldRecMap.get(selectRecordId).Amount;
    // }
    if(selectRecordValue > 0){
      if(parseFloat(selectRecordValue)  > parseFloat(disputOldRecMap.get(selectRecordId).Percentage))
      {
          claimRec[i].showerror = true;
          // claimRec[i].errormsg = 'You can only reduce the amount';
          claimRec[i].errormsg = 'You are unable to increase the amount requested, please enter a reduced value.';
          claimRec[i].adjperbyAGLL = disputOldRecMap.get(selectRecordId).Percentage;
          this.isadjustsubmit = true;
          this.template.querySelector('.disablesubmit').classList.add('disablebutton');

      }
      else
      {
          if(selectRecordValue < claimRec[i].AdjprcntbyTT )
          {
              claimRec[i].showerror = true;
              claimRec[i].errormsg = 'Amount entered should be equal to or greater than amount requested by tenant';
              claimRec[i].adjperbyAGLL = disputOldRecMap.get(selectRecordId).Percentage;
              this.isadjustsubmit = true;
              this.template.querySelector('.disablesubmit').classList.add('disablebutton');

          }
          else
              {
                this.isadjustsubmit = false;
                this.template.querySelector('.disablesubmit').classList.remove('disablebutton');      
                claimRec[i].showerror = false;
                claimRec[i].adjperbyAGLL = parseFloat(selectRecordValue);
              }
          
      }
      //claimRec[i].Agreed_by_Tenant__c = selectRecordValue;
      var AGLLResponseperc = (claimRec[i].adjperbyAGLL * claimRec[i].initialClaimOfagll )/100;
      claimRec[i].amountagreedbyagll = AGLLResponseperc;
    }
  }

  totalamount = parseFloat(totalamount) + parseFloat(claimRec[i].amountagreedbyagll);
  
  this.totalAdjustedAmountbyAGLL = parseFloat(totalamount);
  this.adjustmentamountAGLL = '£'+Number(totalamount.toFixed(2)).toLocaleString("en-US");
  this.adjustmentamounttoTT = '£'+Number((this.casedata.Total_Claimed_by_Landlord__c-parseFloat(totalamount)).toFixed(2)).toLocaleString("en-US");
  console.log('line-->464 ' + totalamount);
}
this.dispitemlist = claimRec;
}

SubmitRepaymentAdjByAGLL (){

var claimedItemsDetailsObj = {};
for(let ind in this.dispitemlist){
  console.log("recordid => " + this.dispitemlist[ind].recordid);
  let detailsObj = {};
  detailsObj['amountagreedbyagll'] = this.dispitemlist[ind].amountagreedbyagll;
  detailsObj['amountagreedbytt'] = this.dispitemlist[ind].amountagreedbytt;
  detailsObj['adjperbyAGLL'] = this.dispitemlist[ind].adjperbyAGLL;
  // detailsObj['agllResponsePercentage'] = this.dispitemlist[ind].agllResponsePercentage;

  claimedItemsDetailsObj[this.dispitemlist[ind].recordid] = detailsObj;
  console.log("claimedItemsDetailsObj => " + JSON.stringify(claimedItemsDetailsObj));
}
var claimedItemsDetailsObjStr = JSON.stringify(claimedItemsDetailsObj);
console.log('line-->500' );
updateRepaymentAdjustmentbyAGLL({caseId: this.casedata.Id, depositAmount: this.casedata.Total_Deposit__c, 
adjustedAmount: this.totalAdjustedAmountbyAGLL, claimedItems: claimedItemsDetailsObjStr})
.then(result=>{
  console.log('updateRepaymentAdjustmentbyAGLL result => ' + result);
  if(result == 'SuccessFully Updated'){
    this.thankYouSectionForAGllDisagreeForTenant=true;
    this.thankyousection =true;
    // this.thankYouSectionForTenantAgree =false;
    // this.thankYouSectionForMakeOffer =false;
    // this.thankYouSectionForTenantAcceptAnOffer =false;
    // this.thankYouSectionForTenantRejectAnOffer =false;
  }
}).catch(error=>{
  console.log('updateRepaymentAdjustmentbyTenant error => ' + JSON.stringify(error));
})

}


notReachAgreementByAGll(){
this.isNotAgreedBtnClicked=true;
this.adjustmentByAGll=false;

}

doSubmitNoAggrementbyAGll(){

var isvalid=true;
const textareavalue = this.template.querySelector('lightning-textarea').value;
this.notreachagreementcomment =textareavalue;


if(this.notreachagreementcomment == undefined){
isvalid = false;
this.errorMsgnew = 'Please review your comments. You are required to enter a minimum of 150 characters and no more than 500.';
this.isErrornew = true;
this.template.querySelector(".errorMsgDiv").scrollIntoView();
}else{
 console.log('@@in not error');
this.isErrornew =false;
} 

if( typeof textareavalue == 'undefined' || (textareavalue.length < 150 || textareavalue.length > 500) ){
console.log('line--> 553 ' + textareavalue.length );
isvalid = false;
this.errorMsgnew = 'Please review your comments. You are required to enter a minimum of 150 characters and no more than 500.';
this.isErrornew = true;
this.template.querySelector(".errorMsgDiv").scrollIntoView();
}else{
 console.log('@@in not error');
this.isErrornew =false;
} 

if(isvalid){
UpdateCaseNoAgreementBYAGll({claimId: this.casedata.Id, cmnts: textareavalue })
.then(result=>{console.log('UpdateCaseNoAgreementBYAGll result => ' + result);
if(result == 'Record successfully updated'){
this.thankyousection =true;
this.thankYouSectionForNoAggrementByAGll=true;
this.thankYouSectionForAGllDisagreeForTenant=false;
this.thankYouSectionForAGllRejectAnOffer =false;
this.thankYouSectionForAGllAcceptAnOffer =false;
this.thankYouSectionForMakeOffer=false;
this.thankYouSectionForAgree=false;

  
}
}).catch(error=>{
console.log('UpdateCaseNoAgreementBYAGll error => ' + JSON.stringify(error));
})
}

}

goToHomePage (){
  window.location.href =  EWIVPlus_Link+this.accessCode;

// let currentURL = window.location.href;
//     console.log('currentURL => ' + currentURL);
//     let homeURL = currentURL.split('/ewinsured/s');
//     console.log('homeURL => ' + homeURL);
//     let redirectToURL = homeURL[0]+'/ewinsured/s/?accessCode='+this.accessCode;
//     console.log('redirectToURL => ' + redirectToURL);
//     window.location.href = redirectToURL; //"https://espdev2-thedisputeservice.cs80.force.com/ewinsured/s/?accessCode="+this.accessCode;
//   this[NavigationMixin.Navigate]({
//     type: 'comm__namedPage',
//     attributes: {
//         pageName: 'home'
//     },
//     state:{
//         accessCode: this.accessCode
//     }
// });

}

showchatbox () {
// alert('line-->661' + this.chatOpen);
this.chatOpen = true;
// alert('line-->662' + this.chatOpen);
updateChatFields({caseId: this.casedata.Id, accessCode: this.accessCode })
.then(result=>{console.log('updateChatFields result => ' + result);
if(result) {
this.chatWrap = result;
console.log('line-->714 ' + JSON.stringify(this.chatWrap.chatList));
var chatList = [];
for(let ind in this.chatWrap.chatList){
let chatObj = {};
chatObj['Id'] = this.chatWrap.chatList[ind].Id;
chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
if(this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId){
  chatObj['selfUserChat'] = true;
}else{
  chatObj['selfUserChat'] = false;
}
chatList.push(chatObj);
}
this.chatList = chatList;
console.log('chatList => '+this.chatList);
}


}).catch(error=>{
console.log('updateChatFields error => ' + JSON.stringify(error), error);
})
var chatOpen = this.chatOpen;
// if(chatOpen == true){
//   setTimeout(()=>{
//     this.showchatbox()
//   }, 2000);
//     // setTimeout(getCallback(() => this.openChatBoxHelper()), 2000)
// }

}

enterClicked(event)
{
var keyCode = (event.which) ? event.which : event.keyCode;
var messageval =this.messageValue;

if(keyCode == 13) {
updateChatHistory
({caseId: this.casedata.Id,
  message : messageval,
  fromId : this.chatWrap.currentContactId,
  toId : this.chatWrap.otherPartyContactId,
  accessCode : this.accessCode })
.then(result=>{console.log('updateChatHistory result => ' + result);
if(result) {
this.chatWrap = result;
this.messageValue = '' ;
console.log('line-->7 ' + JSON.stringify(result));
var chatList = [];
for(let ind in this.chatWrap.chatList){
let chatObj = {};
chatObj['Id'] = this.chatWrap.chatList[ind].Id;
chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
if(this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId){
  chatObj['selfUserChat'] = true;
}else{
  chatObj['selfUserChat'] = false;
}
chatList.push(chatObj);
}
this.chatList = chatList;
console.log('chatList => '+this.chatList);

}

}).catch(error=>{
console.log('updateChatHistory error => ' + JSON.stringify(error));
})


}


}

openFileUpload (){
var chatWrap = this.chatWrap;
if(chatWrap.numberOfEvidences >= 5){
          
  return;
}

getSecureURI({scheme : 'EWI' })
.then(result=>{
    console.log('getSecureURI result => ' + result);
    this.secureURI = result;
    this.showEvidenceCmp = true;
    
}).catch(error=>{
    console.log('getSecureURI error => ' + JSON.stringify(error));
})


}
handleFilelLabelChange(event){
this.fileLable = event.target.value;
}

handleFilesChange (event) {
//var files = event.getSource().get("v.files");
this.message = "";
this.fileList =event.target.files[0]; 
var files = this.fileList;
let icon = files.name.toLowerCase();
this.fileName =files.name;
console.log('icon '+icon); 
const ext = ['.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp'];
var fileTypeCheck = ext.some(el => icon.endsWith(el));
// alert('line--830' + fileTypeCheck );
if(fileTypeCheck==true){
  this.fileLableVisible =true;
}else{
  this.fileLableVisible =false;
} 

console.log('files => ' + JSON.stringify(files));
}

addEvidence(){
   var isvalid = true;
  var files = this.fileList; 
  var getFileLabel = this.fileLable;
  var sizeInMB = (files.size / (1024*1024)).toFixed(2);
  if (!files) {return;}

  if(files){
    
    if(this.fileLableVisible==false){
    let icon = files.name.toLowerCase();
    const ext = ['.pdf', '.doc', '.docx', '.txt', '.rtf','.odt', '.xls', '.xlsx', '.ods', '.msg', '.csv', '.png', '.jpeg', '.jpg', '.gif', '.tiff', '.tif', '.bmp', '.mp3', '.mp4', '.wmv', '.wav', '.ppt', '.pptx'];
    var fileTypeCheck = ext.some(el => icon.endsWith(el));
    if (!fileTypeCheck) {
       return alert("File type not supported!");
    }
    
   else if(sizeInMB > 20){
      isvalid=false;
         return alert("File size is greater than 20mb");
    }
    else{
      isvalid=true;
    }
  }

  if(this.fileLableVisible==true){
  if(getFileLabel==undefined ){
    isvalid=false;
      this.fileLable = 'Please provide a label to upload image.';
  } else if(getFileLabel.length > 50){
    isvalid=false;
      this.fileLable ='Character limit is 50.';
  }
  else{
    isvalid=true;
  }
}
if(isvalid){
  this.createurl();
  }
}
}
// var files = this.fileList;
createurl(){
console.log("this.fileList => " + this.fileList + ' name => ' + this.fileList.name)
const currentDate = new Date();
const timestamp = currentDate.getTime();
var baseUrl = this.secureURI;
var baseUrlLength = baseUrl.length;
var indexOfQueryStart = baseUrl.indexOf("?");
var sasKeys = baseUrl.substring(indexOfQueryStart, baseUrlLength);
var submitUri = baseUrl.substring(0, indexOfQueryStart) + '/'+ this.casedata.Id +'-'+ timestamp +'-'+ this.fileList.name + sasKeys;
var fileNameonAzure = this.casedata.Id +'-'+ timestamp +'-'+ this.fileList.name;

console.log('submitUri => ' + submitUri);
this.azureLink = submitUri;
console.log('this.azureLink => ' + this.azureLink);

var reader = new FileReader()
reader.onload = () => {
  var base64 = reader.result.split(',')[1];     
  console.log('bae64 => ' + base64);
  this.uploadToAzure(this.fileList, submitUri, fileNameonAzure);
}
reader.readAsDataURL(this.fileList)
}

uploadToAzure(file, submitUri, fileNameonAzure) {
//debugger;
var caseId = this.casedata.Id;
var accessCode = this.accessCode;
var fromId = this.chatWrap.currentContactId;
var toId = this.chatWrap.otherPartyContactId;
var fileName= this.fileName;
var azureLink= this.azureLink;
var fileType =(this.fileName).split('.').pop();
var fileSize =this.fileList.size;
var fileLable =this.fileLable;

var xhr = new XMLHttpRequest();
var endPoint = submitUri;

xhr.open("PUT", endPoint, true);
xhr.setRequestHeader('x-ms-blob-type', 'BlockBlob');
console.log('uploadToAzure file type => ' + file.type);
xhr.setRequestHeader('Content-Type', file.type);
xhr.onreadystatechange = () => {

  console.log("xhr.readyState => " + xhr.readyState);
  if (xhr.readyState === 4 && xhr.status === 201) { 
    // String caseId, string accessCode, String fromId, String toId, String fileName, String azureLink,
    //  String fileType, String fileSize, String fileLable, String fileNameInAzure, String scheme){
        console.log('insice saveFile method');
       
        console.log('caseId' + caseId);
        console.log('accessCode' + accessCode);
        console.log('fromId' + fromId);
        console.log('toId' + toId);
        console.log('fileName' + fileName);
        console.log('azureLink' + azureLink);
                  console.log('fileType' + fileType	);
        console.log('fileSize' + fileSize);
        console.log('fileLable' + fileLable);
        console.log('fileNameInAzure' + fileNameonAzure);
      saveFile({
        caseId : caseId,
        accessCode : accessCode,
        fromId : fromId,
        toId : toId,
        fileName: fileName, 
        azureLink: azureLink,
                  fileType : fileType,	
        fileSize : fileSize,
        fileLable : fileLable,
        fileNameInAzure : fileNameonAzure,
        scheme : 'EWI'
      }).then(result=>{
        console.log('saveFile result => '+ result);
        // data = { ...result };
        // var result1 = Object.assign({}, result)
        // Object.preventExtensions(result);
        // finalresult = result;
        this.chatWrap = result;
        this.fileLableVisible = false;
        console.log("fileLableVisible => " + this.fileLableVisible)
        this.fileLable = "";
        this.fileName= "";
        this.showEvidenceCmp = false;
        console.log("showEvidenceCmp => " + this.showEvidenceCmp)


        var chatList = [];
        for(let ind in this.chatWrap.chatList){
          let chatObj = {};
          chatObj['Id'] = this.chatWrap.chatList[ind].Id;
          chatObj['File_Type__c'] = this.chatWrap.chatList[ind].File_Type__c;
          chatObj['File_Location__c'] = this.chatWrap.chatList[ind].File_Location__c;
          chatObj['File_Name__c'] = this.chatWrap.chatList[ind].File_Name__c;
          chatObj['Message__c'] = this.chatWrap.chatList[ind].Message__c;
          if(this.chatWrap.chatList[ind].From__c == this.chatWrap.currentContactId){
            chatObj['selfUserChat'] = true;
          }else{
            chatObj['selfUserChat'] = false;
          }
          chatList.push(chatObj);
        }
        this.chatList = chatList;
        console.log('chatList => '+this.chatList);

        
        // Console log the user with the value returned from the server
        // const toastEvent = new ShowToastEvent({
        //   title: 'Info',
        //   message: 'File Uploaded Successfully'+submitUri,
        //   type: 'success'
        // });
        // this.dispatchEvent(toastEvent);
      }).catch(error=>{
        console.log("saveFile error => " + JSON.stringify(error) + error);
      });
    
  }
  else{
      //image error code
  }
  
}
xhr.send(file);
}

closeChatBox(){
    
this.chatOpen = false;
}
}